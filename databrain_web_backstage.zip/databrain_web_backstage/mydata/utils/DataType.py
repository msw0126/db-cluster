class DataType:

    def __init__(self, field, sparkType):
        self.field = field  # type: str
        self.sparkType = sparkType  # type: str
